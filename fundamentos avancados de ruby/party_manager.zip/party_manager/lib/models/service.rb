module PartyManager
  class Service
    attr_reader :name

    def initialize(name)
      @name = name
    end
  end
end
