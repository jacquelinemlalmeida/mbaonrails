module PartyManager
  class Party
    attr_accessor :name, :date, :food, :music, :guests, :services

    def initialize
      @guests = []
      @services = []
      @food = []
    end
  end
end
