module PartyManager
  class LazyLoader
    def self.filter_guests(guests)
      guests.lazy.map(&:name).select { |n| n.length > 4 }.map(&:upcase).to_a
    end
  end
end
