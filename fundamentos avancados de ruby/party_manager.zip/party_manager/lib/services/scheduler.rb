module PartyManager
  class Scheduler
    def self.schedule_parties(parties)
      threads = parties.map do |party|
        Thread.new do
          sleep(rand(1..3)) # simula tempo de agendamento
          puts "🎉 Agendada: #{party.name} para #{party.date}"
        end
      end
      threads.each(&:join)
    end
  end
end
