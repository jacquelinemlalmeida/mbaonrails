module PartyManager
  class PartyDSL
    attr_reader :party

    def initialize(&block)
      @party = Party.new
      instance_eval(&block)
    end

    def name(value);      @party.name = value; end
    def date(value);      @party.date = value; end
    def food(*items);     @party.food = items; end
    def music(style);     @party.music = style; end
    def guest(name);      @party.guests << Guest.new(name); end
    def service(name);    @party.services << Service.new(name); end
  end
end
