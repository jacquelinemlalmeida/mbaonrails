# PartyManager

**PartyManager** é uma aplicação Ruby pura para gerenciar festas de aniversário de forma simples e organizada. Com uma DSL específica para criar eventos, o sistema permite definir comidas, música, convidados e serviços adicionais com uma sintaxe elegante e fluida.

---

## Objetivo

Este projeto foi desenvolvido como entrega final da disciplina de **Ruby Avançado**, com o objetivo de aplicar na prática os seguintes conceitos:

- Criação de uma **DSL (Domain-Specific Language)** em Ruby
- Utilização de **Enumerable** com **Lazy Evaluation**
- Implementação de **concorrência com Threads**
- Arquitetura modular com **boas práticas de organização e composição de código**

---

## Como usar

1. Clone o repositório:

```bash
git clone https://github.com/seu-usuario/party_manager.git
cd party_manager
ruby bin/app.rb
```

## Exemplo de uso da DSL

```ruby
party = PartyManager::PartyDSL.new do
  name "Festa da Júlia"
  date "2025-10-01"
  food "Pizza", "Bolo", "Coxinha"
  music "Pop"
  guest "Ana"
  guest "Paulo"
  service "DJ"
end.party
```
